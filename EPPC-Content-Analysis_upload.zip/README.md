# EPPC-Content-Analysis

To compare communication behaviors in patient and clinical-team secure messages (SM), measure concordant responses to patient needs, and characterize reconstructed threads by patient–provider gender, race and age.

This repository holds the code and aggregate results for **Aim 2a**: a descriptive content analysis of secure messages annotated with the **EPPC** (Electronic Patient–Provider Communication) codebook.

## Dataset at a glance

| Metric | Value |
|---|---|
| Secure messages | 75,180 |
| Messages with ≥1 EPPC annotation | 70,893 (94.3%) |
| EPPC annotations (spans) | 586,542 |
| Unique codes / subcodes | 59 / 155 |
| EPPC annotations per message | mean 7.80 (SD 6.70), median 6 |

**By direction** (`TO_PAT_YN`)

| Direction | Messages | Annotations | Mean per message (SD) | Median |
|---|---|---|---|---|
| Patient → Provider (`N`) | 39,167 | 302,034 | 7.71 (6.67) | 6 |
| Provider → Patient (`Y`) | 36,013 | 284,508 | 7.90 (6.73) | 7 |

**Most frequent codes**

| Code | Annotations | % of annotations | % of messages |
|---|---|---|---|
| InfoGive | 283,046 | 48.3 | 78.8 |
| PartnershipPatient | 119,595 | 20.4 | 53.8 |
| InfoGiveSDOH | 63,796 | 10.9 | 32.5 |
| PartnershipProvider | 41,371 | 7.1 | 23.3 |
| InfoSeek | 35,248 | 6.0 | 27.6 |
| Socioemotional/Empathy | 25,147 | 4.3 | 20.7 |
| SharedDecisionPatient | 9,176 | 1.6 | 8.9 |
| SharedDecisionProvider | 6,689 | 1.1 | 6.1 |
| InfoSeekSDOH | 2,307 | 0.4 | 2.4 |

The nine codebook codes above account for >99.9% of annotations. The remaining labels (for example SNOMED IDs, ICD-10 codes, misspellings such as `Socioemoral/Empathy`) are rare model-output noise and are listed separately in `results/codebook_counts/EPPC_70k_other_labels_noise.csv`.

> **Note on dates:** only 6 of the 75,180 messages have a `date` value, and one of them is `1935-09`, which is almost certainly a parsing error. The monthly tables are therefore not yet usable for trend analysis.

## Repository structure

```
EPPC-Content-Analysis/
├── scripts/
│   └── eppc_aim2a_analysis.py        # regenerates the Aim 2a summary tables
├── results/
│   ├── EPPC_Aim2a_Overall_Statistics.csv
│   ├── EPPC_Aim2a_Code_Frequency.csv
│   ├── EPPC_Aim2a_Subcode_Frequency.csv
│   ├── EPPC_Aim2a_Intensity.csv          # annotations per message, by direction
│   ├── EPPC_Aim2a_Patient_Provider.csv   # code distribution, by direction
│   ├── EPPC_Aim2a_Summary_Tables.xlsx    # all summary sheets of the Aim 2a workbook (no message text)
│   ├── summary_tables/                   # extra summary sheets from the Aim 2a workbook
│   │   ├── EPPC_Aim2a_Direction.csv          # incl. % of messages with EPPC, by direction
│   │   ├── EPPC_Aim2a_Intensity.csv          # incl. quartiles and EPPC per 100 messages
│   │   ├── EPPC_Aim2a_Monthly_Messages.csv   # only 6 messages carry a date; see note
│   │   └── EPPC_Aim2a_Monthly_Codes.csv
│   └── codebook_counts/                  # code → subcode → sub-subcode frequencies
│       ├── EPPC_70k_code_subcode_subsubcode_counts.csv
│       ├── EPPC_70k_code_totals.csv
│       ├── EPPC_70k_other_labels_noise.csv
│       └── sample1to39_code_subcode_subsubcode_counts.csv
├── data/
│   └── README.md                         # raw data is NOT in this repo — see here
├── index.html                            # standalone to-do app (task tracking)
├── requirements.txt
└── .gitignore
```

## Reproducing the results

The raw message- and annotation-level files contain secure-message text and are kept off GitHub (see [`data/README.md`](data/README.md)). With access to them:

```bash
pip install -r requirements.txt

# place the two input files in data/, then:
python scripts/eppc_aim2a_analysis.py \
    --messages    data/EPPC_Aim2a_Message_Level.csv \
    --annotations data/EPPC_Aim2a_Annotation_Level.csv \
    --out         results/
```

The script writes the five `EPPC_Aim2a_*.csv` tables in `results/`. Its output has been checked against the committed tables and matches exactly.

### Column definitions

- `TO_PAT_YN` — `Y` = clinical team writing **to** the patient; `N` = patient writing to the clinical team.
- `EPPC_occurrences` / `occurrences` — number of annotated spans with that label.
- `unique_messages` — number of distinct messages containing the label at least once.
- `percentage_of_all_annotations` — occurrences ÷ 586,542 × 100.
- `percentage_of_messages` — unique messages ÷ 75,180 × 100.
- `percentage_within_direction` — occurrences ÷ total annotations in that direction × 100.

## Contributing

1. Clone the repo and create a branch: `git checkout -b feature/<short-name>`.
2. Keep raw data in `data/`. It is git-ignored, so it is never committed.
3. Open a pull request against `main`.
