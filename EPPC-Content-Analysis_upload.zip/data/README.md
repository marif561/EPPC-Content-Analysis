# Data (not tracked in git)

The input files for this analysis contain the text of patient–provider secure messages. Even with names replaced by placeholders (`Person1`, `Org1`, …), they are clinical communications, so they are **never committed to this repository**. Everything in `data/` except this README is ignored by `.gitignore`.

To reproduce the results, obtain these files through the project's approved secure storage and place them here:

| File | Rows | Description |
|---|---|---|
| `EPPC_Aim2a_Message_Level.csv` | 75,180 messages | `message_id`, `TO_PAT_YN`, `message`, `num_eppc_annotations`, `has_eppc`, model prompt/outputs (`query`, `gold_answer`, `stage1_out`, `stage2_out`, `final_out`) |
| `EPPC_Aim2a_Annotation_Level.csv` | 586,542 annotations | `message_id`, `annotation_id`, `TO_PAT_YN`, `message`, `span`, `code`, `subcode` |
| `EPPC_Aim2a_Analysis.xlsx` | — | Full workbook (Messages + Annotations sheets plus summaries). The summary sheets are reproduced in `results/summary_tables/`. |

Only the first two files are needed to run `scripts/eppc_aim2a_analysis.py`.
